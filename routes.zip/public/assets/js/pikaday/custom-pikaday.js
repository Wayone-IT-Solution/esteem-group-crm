document.addEventListener('DOMContentLoaded', function() {
var picker = new Pikaday({ field: document.getElementById('datepicker') });
});