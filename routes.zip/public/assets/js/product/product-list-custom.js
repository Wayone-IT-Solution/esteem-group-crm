// basic init table 1
const datatable = new simpleDatatables.DataTable("#basic-3", {
    paging: true,
    tabIndex: 2,
    sortable: true,
  });
  