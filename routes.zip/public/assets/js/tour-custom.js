/*=====================
    Tour js
==========================*/
const tg = new tourguide.TourGuideClient({
    exitOnClickOutside: true
})

tg.start()