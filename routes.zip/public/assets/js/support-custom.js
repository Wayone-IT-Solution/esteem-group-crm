const datatable = new simpleDatatables.DataTable("#support_table", {
    paging: true,
    tabIndex: 1,
});